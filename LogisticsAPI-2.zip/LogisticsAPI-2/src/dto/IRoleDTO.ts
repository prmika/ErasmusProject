
export default interface IRoleDTO {
  id: string;
  name: string
}
