
export interface IUserDTO {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  role: string
}
