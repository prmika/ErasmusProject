import { UniqueEntityID } from "../core/domain/UniqueEntityID";

export class DeliveryPathId extends UniqueEntityID {

}