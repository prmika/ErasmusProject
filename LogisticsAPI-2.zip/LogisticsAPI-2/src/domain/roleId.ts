import { UniqueEntityID } from "../core/domain/UniqueEntityID";

export class RoleId extends UniqueEntityID {

}