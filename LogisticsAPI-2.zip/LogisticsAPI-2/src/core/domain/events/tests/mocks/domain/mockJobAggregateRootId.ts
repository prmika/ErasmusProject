
import { UniqueEntityID } from "../../../../UniqueEntityID";

export const MockJobAggregateRootId = new UniqueEntityID('999');