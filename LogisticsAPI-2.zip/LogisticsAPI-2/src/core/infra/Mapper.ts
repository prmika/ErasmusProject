
export abstract class Mapper<DomainEntityOrValueObject> {
  // public static toDomain (raw: any): T;
  // public static toDTO (t: T): DTO;
  // public static toPersistence (t: T): any;
}