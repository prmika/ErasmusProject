
export interface IRolePersistence {
  domainId: string;
  name: string;
}